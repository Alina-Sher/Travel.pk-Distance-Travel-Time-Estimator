# Travel.pk Distance & Travel Time Estimator (Task TPT-2026-03315)

Calculates straight-line (Haversine) distance between 10 Pakistani cities and estimates travel time at a user-chosen average speed. Includes a 10-pair comparison table against Google Maps driving distances.
Independent task project, not an official Travel.pk product. All results are estimates.

## Status of requirements
- Calculator, 10 cities, adjustable speed, CSV downloads, tests: implemented.
- **Google Maps comparison: all 10 road distances are PENDING.** They could not be collected in the build environment (no network), and no values were guessed. See "Completing the comparison".
- Live URL: **not deployed yet.** Live URL: _(fill in after deployment)_

## Setup (Windows, PowerShell)
```
cd travelpk-distance-estimator
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
macOS/Linux: use `source .venv/bin/activate` instead of the activate line. Open http://localhost:8501.

## Tests
```
python -m pytest -v
```

## Structure
`app.py` (UI) · `src/distance.py` (logic) · `data/cities.csv` · `data/map_comparison.csv` · `tests/test_distance.py`

## Method
- **Haversine:** a = sin²(Δφ/2) + cos φ1 · cos φ2 · sin²(Δλ/2); d = 2R·asin(√a), R = 6371.0088 km; `a` is clamped to [0, 1].
- **Travel time:** hours = straight-line km ÷ average km/h. Not a road ETA.
- **Table columns:** absolute difference = |road − straight|; percent = difference ÷ straight × 100 (blank if straight is 0).

## Completing the comparison (manual, ~10 minutes)
For each row in `data/map_comparison.csv`:
1. Open the `source_url` (Google Maps driving directions).
2. Note the distance of the route Google selects as the default and the route name.
3. Set `road_km` to that number, `status` to `verified`, `date_checked` to today's date (YYYY-MM-DD), and replace the PENDING text in `explanation` with what you actually observed (route chosen, why it differs).
4. Re-run the app; difference columns fill in automatically. Rows stay "Pending" unless `status` is `verified` and `road_km` is set.

## Limitations
- Straight-line distance is always shorter than road distance. Routes, terrain, traffic, stops and road conditions are ignored.
- City coordinates are approximate centres typed from general geographic knowledge and were **not** re-verified against a live source in this build; cross-check with GeoNames or OpenStreetMap before submitting.
- Google may choose different routes over time.

## GitHub and free deployment
1. Create an empty public repository on github.com (no README).
2. In the project folder:
```
git init
git add .
git commit -m "Travel.pk distance estimator"
git branch -M main
git remote add origin https://github.com/<your-username>/travelpk-distance-estimator.git
git push -u origin main
```
3. Go to share.streamlit.io, sign in with GitHub, choose New app, select the repository, branch `main`, main file `app.py`, then Deploy.
4. Open the generated URL, test the calculator and downloads, then paste the URL into the "Live URL" line above and push again.
No secrets are required or included.
