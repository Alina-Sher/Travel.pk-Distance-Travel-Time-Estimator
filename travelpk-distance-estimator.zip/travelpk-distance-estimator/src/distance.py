"""Calculation and data-loading logic (no Streamlit code here)."""
import math
from pathlib import Path
import pandas as pd

EARTH_RADIUS_KM = 6371.0088
DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def validate_coordinates(lat, lon):
    """Raise ValueError unless lat is in [-90, 90] and lon in [-180, 180]."""
    for name, v, lim in (("latitude", lat, 90), ("longitude", lon, 180)):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or math.isnan(v) or math.isinf(v):
            raise ValueError(f"{name} must be a finite number")
        if abs(v) > lim:
            raise ValueError(f"{name} must be between -{lim} and {lim}")


def haversine_km(lat1, lon1, lat2, lon2):
    """Straight-line (great-circle) distance in km between two points."""
    validate_coordinates(lat1, lon1)
    validate_coordinates(lat2, lon2)
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi, dlam = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlam / 2) ** 2
    a = min(1.0, max(0.0, a))  # guard against floating-point drift
    return 2 * EARTH_RADIUS_KM * math.asin(math.sqrt(a))


def travel_hours(distance_km, speed_kmh):
    """Hours = distance / speed. Speed must be positive."""
    if speed_kmh is None or speed_kmh <= 0:
        raise ValueError("Average speed must be greater than zero")
    if distance_km < 0:
        raise ValueError("Distance cannot be negative")
    return distance_km / speed_kmh


def format_duration(hours):
    """Format hours as e.g. '3 hr 25 min' (rounded to whole minutes)."""
    total = round(hours * 60)
    h, m = divmod(total, 60)
    return f"{h} hr {m:02d} min" if h else f"{m} min"


def compare(straight_km, road_km):
    """Return (absolute_diff_km, percent_diff) or (None, None) if road_km is missing.
    Percent uses straight-line distance as the denominator; zero denominator -> None."""
    if road_km is None or pd.isna(road_km):
        return None, None
    diff = abs(road_km - straight_km)
    return diff, (diff / straight_km * 100 if straight_km > 0 else None)


def load_cities(path=DATA_DIR / "cities.csv"):
    """Load and validate cities; raises ValueError with a readable message."""
    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        raise ValueError(f"City file not found: {path}")
    missing = {"city", "latitude", "longitude"} - set(df.columns)
    if missing:
        raise ValueError(f"cities.csv is missing columns: {sorted(missing)}")
    for i, r in df.iterrows():
        try:
            validate_coordinates(float(r["latitude"]), float(r["longitude"]))
        except (ValueError, TypeError) as e:
            raise ValueError(f"Invalid coordinates for row {i + 2} ({r['city']}): {e}")
    return df


def city_distance_km(cities, origin, destination):
    o = cities.set_index("city").loc[origin]
    d = cities.set_index("city").loc[destination]
    return haversine_km(float(o.latitude), float(o.longitude), float(d.latitude), float(d.longitude))


def build_comparison(cities, path=DATA_DIR / "map_comparison.csv"):
    """Merge the manual road data with calculated straight-line distances."""
    raw = pd.read_csv(path, keep_default_na=True)
    rows = []
    for _, r in raw.iterrows():
        s = city_distance_km(cities, r["origin"], r["destination"])
        road = r["road_km"] if pd.notna(r["road_km"]) else None
        diff, pct = compare(s, road)
        verified = road is not None and r["status"] == "verified"
        rows.append({"Origin": r["origin"], "Destination": r["destination"],
                     "Straight-line (km)": round(s, 1),
                     "Google Maps road (km)": road if verified else None,
                     "Abs. difference (km)": round(diff, 1) if verified else None,
                     "Difference (%)": round(pct, 1) if verified and pct is not None else None,
                     "Status": "Verified" if verified else "Pending manual check",
                     "Date checked": r["date_checked"] if pd.notna(r["date_checked"]) else "",
                     "Explanation": r["explanation"], "Route link": r["source_url"]})
    return pd.DataFrame(rows)
