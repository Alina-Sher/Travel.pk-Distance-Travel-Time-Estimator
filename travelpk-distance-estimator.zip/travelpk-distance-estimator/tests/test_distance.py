import pytest
import pandas as pd
from src import distance as d

CITIES = d.load_cities()


def test_at_least_10_cities_with_valid_coordinates():
    assert len(CITIES) >= 10
    for _, r in CITIES.iterrows():
        d.validate_coordinates(float(r.latitude), float(r.longitude))


def test_required_cities_present():
    need = {"Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar", "Quetta", "Hyderabad", "Sialkot"}
    assert need <= set(CITIES.city)


def test_identical_points_zero():
    assert d.haversine_km(31.5, 74.3, 31.5, 74.3) == 0


def test_symmetric():
    assert d.haversine_km(31.5, 74.3, 33.6, 73.0) == pytest.approx(d.haversine_km(33.6, 73.0, 31.5, 74.3))


def test_known_values():
    assert d.haversine_km(0, 0, 0, 1) == pytest.approx(111.195, abs=0.01)      # 1 degree of equator
    assert d.haversine_km(0, 0, 0, 180) == pytest.approx(3.141592653589793 * d.EARTH_RADIUS_KM, rel=1e-9)
    assert 250 < d.city_distance_km(CITIES, "Lahore", "Islamabad") < 300       # plausible straight line


def test_distinct_cities_positive():
    names = list(CITIES.city)
    assert all(d.city_distance_km(CITIES, a, b) > 0 for a in names for b in names if a != b)


def test_faster_speed_less_time():
    assert d.travel_hours(300, 100) < d.travel_hours(300, 60)


def test_bad_speed_rejected():
    for s in (0, -10, None):
        with pytest.raises(ValueError):
            d.travel_hours(100, s)


def test_invalid_coordinates_rejected():
    for lat, lon in ((91, 0), (0, 181), (float("nan"), 0), ("a", 0)):
        with pytest.raises(ValueError):
            d.haversine_km(lat, lon, 0, 0)


def test_duration_format():
    assert d.format_duration(3 + 25 / 60) == "3 hr 25 min"
    assert d.format_duration(0.5) == "30 min"


def test_compare_math_and_zero_denominator():
    assert d.compare(100, 130) == (30, 30.0)
    assert d.compare(0, 10) == (10, None)
    assert d.compare(100, None) == (None, None)


def test_ten_comparison_pairs_exist_and_distinct():
    comp = d.build_comparison(CITIES)
    assert len(comp) >= 10
    assert len(set(zip(comp.Origin, comp.Destination))) == len(comp)
    assert ("Karachi", "Lahore") in set(zip(comp.Origin, comp.Destination))


def test_unverified_rows_have_no_fabricated_distance():
    comp = d.build_comparison(CITIES)
    pending = comp[comp.Status != "Verified"]
    assert pending["Google Maps road (km)"].isna().all()
    assert pending["Abs. difference (km)"].isna().all()


def test_verified_row_computes_difference(tmp_path):
    p = tmp_path / "c.csv"
    p.write_text("origin,destination,road_km,status,date_checked,source_url,explanation\n"
                 "Lahore,Islamabad,380,verified,2026-10-20,http://x,test\n")
    row = d.build_comparison(CITIES, p).iloc[0]
    s = d.city_distance_km(CITIES, "Lahore", "Islamabad")
    assert row["Abs. difference (km)"] == pytest.approx(abs(380 - s), abs=0.06)
