"""Travel.pk Distance & Travel Time Estimator (Streamlit UI)."""
import streamlit as st
from src import distance as d

st.set_page_config(page_title="Travel.pk Distance & Travel Time Estimator", page_icon="🧭", layout="centered")
st.markdown("""<style>
.block-container{padding-top:1.5rem;max-width:960px}
h1{color:#0b6b4f;font-size:1.8rem!important}
[data-testid=stMetric]{background:#f1f8f5;border:1px solid #cfe5db;border-radius:12px;padding:12px}
@media(max-width:640px){h1{font-size:1.4rem!important}}
</style>""", unsafe_allow_html=True)

st.title("Travel.pk Distance & Travel Time Estimator")
st.caption("Straight-line distance and a rough travel-time estimate between Pakistani cities. "
           "**These are estimates, not road routes or ETAs.** Independent task project; not an official Travel.pk product.")


@st.cache_data
def get_data():
    cities = d.load_cities()
    return cities, d.build_comparison(cities)


try:
    cities, comp = get_data()
except ValueError as e:
    st.error(f"Could not load data: {e}")
    st.stop()

tab1, tab2, tab3, tab4 = st.tabs(["Trip calculator", "City coordinates", "Map comparison", "Methodology"])
names = cities["city"].tolist()

with tab1:
    c1, c2 = st.columns(2)
    origin = c1.selectbox("Origin", names, index=names.index("Lahore") if "Lahore" in names else 0)
    dest = c2.selectbox("Destination", names, index=names.index("Islamabad") if "Islamabad" in names else 1)
    speed = st.slider("Average speed (km/h)", 20, 120, 80, 5)
    if origin == dest:
        st.warning("Origin and destination are the same city, so the distance is 0 km. Please choose two different cities.")
    else:
        km = d.city_distance_km(cities, origin, dest)
        hrs = d.travel_hours(km, speed)
        m1, m2, m3 = st.columns(3)
        m1.metric("Straight-line distance", f"{km:,.1f} km")
        m2.metric("Average speed", f"{speed} km/h")
        m3.metric("Estimated duration", d.format_duration(hrs))
        st.info(f"Estimated time = {km:,.1f} km ÷ {speed} km/h = {hrs:.2f} hours. Real road trips are usually longer because roads are not straight, "
                "and traffic, stops and road conditions add time.")

with tab2:
    q = st.text_input("Filter cities", placeholder="Type part of a city name")
    view = cities[cities["city"].str.contains(q, case=False, na=False)] if q else cities
    st.dataframe(view[["city", "latitude", "longitude"]], hide_index=True, use_container_width=True)
    st.caption("Coordinates are approximate city-centre locations. Sources are listed in data/cities.csv.")
    st.download_button("Download cities CSV", cities.to_csv(index=False), "cities.csv", "text/csv")

with tab3:
    n_ok = int((comp["Status"] == "Verified").sum())
    st.markdown(f"**Comparison status: {n_ok} of {len(comp)} pairs verified** against Google Maps driving distance.")
    if n_ok < len(comp):
        st.warning("Pending rows have no road distance yet. Open the route link and enter the distance shown (see README).")
    st.dataframe(comp, hide_index=True, use_container_width=True,
                 column_config={"Route link": st.column_config.LinkColumn("Route link", display_text="Open route")})
    st.caption("Road distances depend on the route Google selects and may change over time.")
    st.download_button("Download comparison CSV", comp.to_csv(index=False), "map_comparison_results.csv", "text/csv")

with tab4:
    st.markdown("""
**Formula.** Haversine great-circle distance with Earth radius 6,371.0088 km, from each city's latitude/longitude.
**Travel time.** distance ÷ average speed (you set the speed).
**Comparison.** Absolute difference = |road − straight-line|; percentage = difference ÷ straight-line × 100.

**Limitations.** Straight-line distance is not road distance. Coordinates are approximate city centres.
The estimate ignores routes, traffic, stops, border/checkpoint delays and road conditions.
""")
